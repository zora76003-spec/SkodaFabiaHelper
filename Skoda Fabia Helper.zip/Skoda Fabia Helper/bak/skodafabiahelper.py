import tkinter as tk
from PIL import Image, ImageTk


root = tk.Tk()
root.title("Skoda Fabia Helper")
root.geometry("600x800")
root.configure(bg="#234b8c")
root.iconbitmap("icon.ico")

#  Создание картинки
image=Image.open("fabiaicon.jpg")
image=image.resize((500,300))
photo=ImageTk.PhotoImage(image)
label = tk.Label(root, image=photo,bg="#234b8c")
label.image=photo
label.pack(pady=20)

#  Создание текста
label1 = tk.Label(root, text="SKODA FABIA 2018\n Цвет: Синий\n Тип: Легковой\n Топливо: Бензин\n Объём двигателя: 999\n Маса/Макс. маса: 1110/1565\n Прошлые номера: AA7679TK\n Новые номера: KA3066PT\n VIN: TMBEP2NJXJB500851")
label1.pack(pady=20)
label2 = tk.Label(root, text="Сделано Артемом в подарок Игорю", bg="#234b8c")
label2.pack(pady=50)

root.mainloop()
